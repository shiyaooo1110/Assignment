const drivers = [
    { name: "Alice", plate: "ABC1234", phone: "012-7777444" },
    { name: "Bob", plate: "XYZ5678" , phone: "018-2323122"},
    { name: "Charlie", plate: "LMN4321" , phone: "019-8882923"},
  ];
  
  export default drivers;
  