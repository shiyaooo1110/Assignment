import React from "react";
import {Text,View} from "react-native";

const ProfileScreen = () => {
    return(
        <View style={{flex:1, justifyContent:'center', alignItems:'center'}}>
        <Text style={{ fontSize:50, color: 'black'}}>Profile</Text>
        </View>

    )
}

export default ProfileScreen;