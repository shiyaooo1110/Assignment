exports.settings = {
    // If you use actual device, can try to set it to the IP address of the server
    serverPath: 'http://10.0.2.2:5000',
  }